Proyecto : Detección del riesgo de hipertensión

Facultad de Medicina y Ciencias Biomédicas
Universidad Autónoma de Chihuahua

Integrantes: 
Valeria Elisa Gutiérrez Carmona 
Mario Alberto Luna Montes